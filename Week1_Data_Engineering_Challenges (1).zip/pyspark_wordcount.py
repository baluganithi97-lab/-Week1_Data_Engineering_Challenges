
from pyspark.sql import SparkSession

# Create Spark session
spark = SparkSession.builder.appName("WordCount").getOrCreate()

# Read text file
rdd = spark.sparkContext.textFile("data.txt")

# Split lines into words and count
word_counts = (rdd.flatMap(lambda line: line.split(" "))
                   .map(lambda word: (word, 1))
                   .reduceByKey(lambda a, b: a + b))

# Collect and print results
for word, count in word_counts.collect():
    print(f"{word}: {count}")

spark.stop()
