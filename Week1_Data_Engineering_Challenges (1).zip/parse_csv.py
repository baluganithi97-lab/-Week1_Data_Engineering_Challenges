
import pandas as pd

# Read CSV file
df = pd.read_csv("data.csv")

# Display first 5 rows
print(df.head())

# Print column names
print("Columns:", df.columns.tolist())
