
import json
import psycopg2

# Load JSON data
with open('data.json') as f:
    data = json.load(f)

# Connect to PostgreSQL
conn = psycopg2.connect(
    host="localhost",
    database="mydb",
    user="postgres",
    password="yourpassword"
)
cursor = conn.cursor()

# Create table
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    city VARCHAR(100)
)
""")

# Insert JSON data
for record in data:
    cursor.execute(
        "INSERT INTO users (name, age, city) VALUES (%s, %s, %s)",
        (record['name'], record['age'], record['city'])
    )

conn.commit()
cursor.close()
conn.close()
